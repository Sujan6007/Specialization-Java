import { Component, Input, OnInit, Output,EventEmitter, OnChanges, SimpleChanges} from '@angular/core';
// import { EventEmitter } from 'stream';

@Component({
  selector: 'child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit{

  @Input("child")
  fruits:string='apple'

  @Output() newFruit = new EventEmitter<String>();




  ngOnInit(): void {
  }
  sendData(value:string){
    this.newFruit.emit(value);

  }
}
