import { Component, DoCheck, Input, OnChanges, OnInit, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-life-cycle',
  templateUrl: './life-cycle.component.html',
  styleUrls: ['./life-cycle.component.css']
})
export class LifeCycleComponent implements OnInit,DoCheck,OnChanges{
  @Input()
  prop:number=1
  constructor() { 
    console.log('component is initialized')
  }
  ngOnChanges(_changes: SimpleChanges): void {
    
    console.log(this.prop)
  }
  ngDoCheck(): void {
    console.log('ng do check is called')
  }

  ngOnInit(): void {
    console.log('init method is called')
  }

}
