import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'power'
})
export class PowerPipe implements PipeTransform {

  transform(value: number, ...args: number[]): unknown {
    var result = value;
    for(let i=1; i<args[0]; i++){
        result=result*value;
    }
    return result;
  }

}
