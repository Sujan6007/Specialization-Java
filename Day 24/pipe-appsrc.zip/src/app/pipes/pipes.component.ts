import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pipes',
  templateUrl: './pipes.component.html',
  styleUrls: ['./pipes.component.css']
})
export class PipesComponent implements OnInit {
name:string="demo text";
DOB:Date=new Date();
amount:number=23000;
  constructor() { }

  ngOnInit(): void {
  }

}
