import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  msg:string=" ";
  prop:string=" ";
  valid:boolean=true;
  demo:any=[
    {'email':'sujan@gmail.com','password':'123456'},
    {'email':'ram@gmail.com','password':'123456'},
    {'email':'farvej@gmail.com','password':'123456'},
    {'email':'raj@gmail.com','password':'123456'}

  ]

  constructor() { }

  ngOnInit(): void {
  }
  login(value: any){
    //  if(value.emailid == "sri@gmail.com" && value.password == "12345")
    if(value.email==this.demo.email && value.password ==this.demo.password)
     { this.msg=`Successfully logged in`; this.prop=`#006400`; 
    } 
    else { this.msg=`login not succesful`; this.prop=`red`; 
  } 
  console.log(value.emailid);
   console.log(value.password); }
}
