import React from "react";
// import 'bootstrap/dist/css/bootstrap.min.css';
import './images.css';

function Images(){
    return(
        <div>
            <br></br>
        <div class="product">
        <div class="product-img">
        <img src="https://m.media-amazon.com/images/I/41Q8WQ0TIkL.jpg" alt=""></img>
        <span class="tag">new</span>
        </div>
        <div class="product-listing">
        <div class="content">
        <h1 class="name">laptop bag</h1>
        <p class="info">Protect your laptop in style—get this snug, lightweight laptop sleeve! To prevent any scratch marks, it contains an internal padded zipper and its interior is fully lined with faux fur. What’s more, it’s made from a material that’s resistant to water, oil, and heat, making sure your laptop sleeve looks as sharp as you any day of the week!</p>
        <p class="price">$ 299</p>
        <div class="btn-and-rating-box">
            <div class="rating">
                <img src="https://www.pngkit.com/png/detail/201-2013815_estrella-amarilla-rate-star-icon.png" alt=""></img>
                <img src="https://www.pngkit.com/png/detail/201-2013815_estrella-amarilla-rate-star-icon.png" alt=""></img>
                <img src="https://www.pngkit.com/png/detail/201-2013815_estrella-amarilla-rate-star-icon.png" alt=""></img>
                <img src="https://www.pngkit.com/png/detail/201-2013815_estrella-amarilla-rate-star-icon.png" alt=""></img>
                <img src="https://www.pngkit.com/png/detail/201-2013815_estrella-amarilla-rate-star-icon.png" alt=""></img>
                {/* <img src="https://ps.w.org/rate-star-review/assets/icon-256x256.png?rev=1962639" alt=""></img> */}
            </div>
            <button class="btn">buy now</button>
        </div>
        </div>
        </div>
        </div>
        <br></br>
        <br></br>
        <div class="product">
        <div class="product-img">
        <img src="https://5.imimg.com/data5/GA/PQ/MY-27070405/college-bags-500x500.jpg" alt=""></img>
        <span class="tag">new</span>
        </div>
        <div class="product-listing">
        <div class="content">
        <h1 class="name">college bag</h1>
        <p class="info">Cosmus Backpack is ideal for school and college students, available in vibrant colours. Carry it in style and stand out from regular college bags. Its big compartment has enough space to accommodate all your books and other essential items required daily in school / college. Front vertical organiser pocket is sufficiently big to hold your lunch box and other small items. </p>
        <p class="price">$ 399</p>
        <div class="btn-and-rating-box">
            <div class="rating">
                <img src="https://www.pngkit.com/png/detail/201-2013815_estrella-amarilla-rate-star-icon.png" alt=""></img>
                <img src="https://www.pngkit.com/png/detail/201-2013815_estrella-amarilla-rate-star-icon.png" alt=""></img>
                <img src="https://www.pngkit.com/png/detail/201-2013815_estrella-amarilla-rate-star-icon.png" alt=""></img>
                <img src="https://www.pngkit.com/png/detail/201-2013815_estrella-amarilla-rate-star-icon.png" alt=""></img>
                <img src="https://www.pngkit.com/png/detail/201-2013815_estrella-amarilla-rate-star-icon.png" alt=""></img>
                {/* <img src="https://ps.w.org/rate-star-review/assets/icon-256x256.png?rev=1962639" alt=""></img> */}
            </div>
            <button class="btn">buy now</button>
        </div>
        </div>
        </div>
        </div>
        <br></br>
        <br></br>
        <div class="product">
        <div class="product-img">
        <img src="https://m.media-amazon.com/images/I/41uNevUMQ8L.jpg" alt=""></img>
        <span class="tag">new</span>
        </div>
        <div class="product-listing">
        <div class="content">
        <h1 class="name">Leather bag</h1>
        <p class="info"> Leather purses and leather bags are as varied as the styles that are attached to them. ... The concept of the bag is compact and streamline with a short strap that can be worn over the shoulder. Barrel a handbag with a long cylinder shape that resembles a barrel.</p>
        <p class="price">$ 499</p>
        <div class="btn-and-rating-box">
            <div class="rating">
                <img src="https://www.pngkit.com/png/detail/201-2013815_estrella-amarilla-rate-star-icon.png" alt=""></img>
                <img src="https://www.pngkit.com/png/detail/201-2013815_estrella-amarilla-rate-star-icon.png" alt=""></img>
                <img src="https://www.pngkit.com/png/detail/201-2013815_estrella-amarilla-rate-star-icon.png" alt=""></img>
                <img src="https://www.pngkit.com/png/detail/201-2013815_estrella-amarilla-rate-star-icon.png" alt=""></img>
                <img src="https://www.pngkit.com/png/detail/201-2013815_estrella-amarilla-rate-star-icon.png" alt=""></img>
                {/* <img src="https://ps.w.org/rate-star-review/assets/icon-256x256.png?rev=1962639" alt=""></img> */}
            </div>
            <button class="btn">buy now</button>
        </div>
        </div>
        </div>
        </div>
</div>
    
    );
}
export default Images;