import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import Navbar from './components/navbar';
import Images from './components/images';

function App() {
  return (
    <div>
      <Navbar></Navbar>
      <Images></Images>
  
    </div>
  );
}

export default App;
