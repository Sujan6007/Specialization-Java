package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EmpService {
	@Autowired
	EmpRepo repo;
	public void saveEmp(Employee emp) {
		repo.save(emp);
	}

}
