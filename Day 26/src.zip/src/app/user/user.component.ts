import { Component, DoCheck, OnInit } from '@angular/core';
import { DataService } from '../data.service';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit, DoCheck {
  msg:any=[];
  constructor(private data:DataService) { }

  ngOnInit(): void {
  }
  ngDoCheck():void{
    this.msg=this.data.callData();
  }
  send(msg:any):void
  {
    this.msg = this.data.dataServe("User  : "+msg);
    
    // console.log(`from:peter ${msg}`);
    // this.msg=`Ramesh : ${msg}`;
  }

}
