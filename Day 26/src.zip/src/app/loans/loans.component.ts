import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loans',
  templateUrl: './loans.component.html',
  styleUrls: ['./loans.component.css']
})
export class LoansComponent implements OnInit {
carval:number=0;
homeval:number=0;
personalval:number=0;

  constructor() { }

  ngOnInit(): void {
  }
  home(v1 :any, v2:any){
    this.homeval= Math.round(v1*v2*0.10);
    console.log(this.homeval);
    }
    car(v1 :any, v2:any){
    this.carval=Math.round(v1*v2*0.07);
    console.log(this.carval);
    }
    personal(v1 :any, v2:any){
    this.personalval=Math.round(v1*v2*0.05);
    console.log(this.personalval);
    }

}
