import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  msg:any=[];

  constructor(private data:DataService) { }

  ngOnInit(): void {
  }
  ngDoCheck():void{
    this.msg=this.data.callData();
  }
  send(msg:any):void{
    this.msg = this.data.dataServe("Admin : "+msg);

  }

}
