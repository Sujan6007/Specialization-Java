package com.annotation.bean;

import com.example.TextEditor;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainApp {
    public static void main(String[] args) {
        ApplicationContext context = new
                ClassPathXmlApplicationContext("company.xml");
        Employee emp= (Employee) context.getBean("myemployee");
        emp.getId();
        emp.getName();


    }
}