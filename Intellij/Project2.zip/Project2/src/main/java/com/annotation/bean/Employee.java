package com.annotation.bean;
import javax.annotation.Resource;

public class Employee {
    private String eid;
    private String name;

    @Resource(name = "TCS")
    private Company company;

    public String getId() {
        return eid;
    }

    public void setId(String eid) {
        this.eid = eid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name=name;
    }
}