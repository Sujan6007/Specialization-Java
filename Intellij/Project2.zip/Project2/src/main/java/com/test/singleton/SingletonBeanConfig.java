package com.test.singleton;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

public class SingletonBeanConfig {
    @Bean
    @Scope(value="singleton")
    public SampleBean getBean()
    {
        return new SampleBean();
    }
}
