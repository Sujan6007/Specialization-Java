package com.test.singleton;

public class SampleBean {
    public SampleBean()
    {
        System.out.println("Sample Bean instance is created......");
    }
}
