public class ProductBean {

}
