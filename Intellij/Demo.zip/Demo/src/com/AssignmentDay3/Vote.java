package com.AssignmentDay3;

import java.util.Scanner;

public class Vote {
    static void eligible(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the age");
        int age = sc.nextInt();
        if(age >= 18){
            System.out.println("Eligible to vote");
        }else{
            System.out.println("Not eligible");
        }
    }

    public static void main(String[] args) {
        Vote.eligible();
    }
}
