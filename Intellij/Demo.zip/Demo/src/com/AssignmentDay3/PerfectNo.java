package com.AssignmentDay3;

import java.util.Scanner;

public class PerfectNo {
    public static void main(String args[]) {
        for(int i =1;i<=1000;i++)
            perfect(i);



    }
    public static void perfect(int n){
        int q =0;
        for(int i = 1;i<=n/2;i++){
            if(n%i==0){
                q = q+i;
            }
            if(q==n) {
                System.out.println(q);
                break;
            }
        }
    }
}


