package com.AssignmentDay3;

import java.util.Scanner;

public class Grades {
    static void display(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the marks");
        int marks = sc.nextInt();

        if(marks<=40){
            System.out.println("Fail");
        }
        else if(marks>=41 && marks<=50){
            System.out.println("Grade is DD");
        }
        else if(marks>=51 && marks<=60){
            System.out.println("Grade is CD");
        }
        else if(marks>=61 && marks<=70){
            System.out.println("Grade is BC");
        }
        else if(marks>=71 && marks<=80){
            System.out.println("Grade is BB");
        }
        else if(marks>=81 && marks<=90){
            System.out.println("Grade is AB");
        }
        else if(marks>=91 && marks<=100){
            System.out.println("Grade is  AA");
        }
        else{
            System.out.println("Enter correct marks");
        }
    }

    public static void main(String[] args) {
        Grades.display();
    }

}

