package com.AssignmentDay3;

import java.util.Scanner;

public class Sum {
    static int add(int a, int b){

        return  a+b;

    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the 2 numbers");
        int a = sc.nextInt();
        int b = sc.nextInt();
        System.out.println("the sum  = "+add(a,b));

    }
}
