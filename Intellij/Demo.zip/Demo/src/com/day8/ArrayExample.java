package com.day8;

public class ArrayExample {
    public static void main(String[] args) {
        int salaries[] = {50000, 75340, 110500, 98270, 39400,45000};
        for(int i=0; i<salaries.length; i++) {
            System.out.println("The element at index " + i + " has the value of " + salaries[i]);
        }
    }
}
