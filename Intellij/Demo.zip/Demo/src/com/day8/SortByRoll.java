package com.day8;

import java.util.Comparator;

public class SortByRoll implements Comparator<Student> {
    public int compare(Student a, Student b)
    {
        return a.id - b.id;
    }

}
