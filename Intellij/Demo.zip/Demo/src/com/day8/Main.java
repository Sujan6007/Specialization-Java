package com.day8;

import java.util.ArrayList;
import java.util.Collections;
import java.lang.*;

public class Main {
    public static void main(String[] args) {
        ArrayList<Student> ar = new ArrayList<Student>();
        ar.add(new Student(3, "sujan", 21));
        ar.add(new Student(2, "suraj", 22));
        ar.add(new Student(1, "ram", 21));

        Collections.sort(ar, new SortByRoll());

        System.out.println("\nSorted by id");
        for (int i=0; i<ar.size(); i++)
            System.out.println(ar.get(i));

    }
}
