package com.day9.excercise;

import java.util.HashMap;
import java.util.Scanner;

public class MapManager {
    public static void main(String[] args) {
        HashMap<String,Integer> map = new HashMap<>();
        map.put("suhas",10);
        map.put("ram",30);
        map.put("laxman",40);
        map.put("markram",20);
        map.put("veera",70);
        map.put("zadran",90);
        System.out.println(map);
        System.out.println("enter the name to be searched get key");
        Scanner sc = new Scanner(System.in);
        String key = sc.next();
        if (map.containsKey(key)){
            Integer a = map.get(key);
            System.out.println("value for key " +key+ " is " +a);
        }
        else
        {
            System.out.println("wrong choice ");
        }
    }
}
