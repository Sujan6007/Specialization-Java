package com.day9.excercise;

import java.util.Date;

public class DateGenerator {
    public static void main(String[] args) {
        Date date = new Date();
        System.out.println("Todays date is "+date);
    }
}
