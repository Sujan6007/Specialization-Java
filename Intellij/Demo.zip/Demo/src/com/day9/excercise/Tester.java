package com.day9.excercise;

import java.util.ArrayList;
import java.util.List;

public class Tester {
    public static void main(String[] args) {
        List<String> list1 = new ArrayList<String>();//line 1
        List<String > list2 = list1;//line 2
        list2.add(new String("ram"));//line 3
        System.out.println(list2.size());//line 4
    }
}
