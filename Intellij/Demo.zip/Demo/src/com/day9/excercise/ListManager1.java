package com.day9.excercise;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ListManager1 {
    public static void main(String[] args) {
        ArrayList<String> list = new ArrayList<String>();
        list.add("Suraj");
        list.add("Ajay");
        list.add("Kabir");
        list.add("Ram");
        list.add("Sujan");
        list.add("Vjay");
        System.out.println("Before sorting "+list);
        Collections.sort(list);
        System.out.println("After sorting "+list);
    }
    }
