package com.day9.excercise;

import java.util.ArrayList;
import java.util.List;

public class ListManager {
    public static void main(String[] args) {
        ArrayList<Integer> arr1 = new ArrayList<Integer>();
        arr1.add(1);
        arr1.add(2);
        arr1.add(3);
        arr1.add(4);
        arr1.add(5);
        arr1.add(6);
        System.out.println("Array list 1 are "+arr1);
        ArrayList<Integer> arr2 = new ArrayList<Integer>();
        arr2.add(1);
        arr2.add(2);
        arr2.add(3);
        arr2.add(4);

        System.out.println("Array list 2 are "+arr2);
        arr1.removeAll(arr2);
        System.out.println("after the removing the elements "+arr1);
    }
}
