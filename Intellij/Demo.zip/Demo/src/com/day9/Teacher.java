package com.day9;

public class Teacher {
    private String name;
    private int classId;

    public Teacher() {
        this.name = name;
        this.classId=classId;
    }

    public String getName() {
        return name;
    }

    public String setName(String name) {
        this.name = name;
        return name;
    }

    public int getClassId() {
        return classId;
    }

    public void setClassId(int classId) {
        this.classId = classId;
    }
}
