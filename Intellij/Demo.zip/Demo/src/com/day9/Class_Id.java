package com.day9;

public class Class_Id {
    private int classNo;

    public Class_Id() {
        this.classNo = classNo;
    }

    public int getClassNo() {
        return classNo;
    }

    public int setClassNo(int classNo) {
        this.classNo = classNo;
        return classNo;
    }
}
