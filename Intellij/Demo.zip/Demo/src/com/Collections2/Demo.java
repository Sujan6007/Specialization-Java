package com.Collections2;

import java.util.stream.*;

public class Demo {
    public static void main(String[] args) {
        Stream<String> fruit = Stream.of("Apple","Banana","Orange","kiwi");
        fruit.filter(s->s.contains("a"))
        .map(String::toUpperCase)
                .sorted()
                .forEach(System.out::println);

    }
}
