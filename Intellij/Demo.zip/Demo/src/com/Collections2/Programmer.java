package com.Collections2;

public class Programmer extends Emp {
    public Programmer(String name, int age, int sal, String des) {
        this.name = name;
        this.age = age;
        this.salary = sal;
        this.des = des;
    }

    public void display() {
        System.out.println(this.name + " " + this.age + " " + this.salary + " " + this.des);
    }

    @Override
    public void raise(int r) {
        this.salary = this.salary + this.raise;
        System.out.println("The total is" + this.salary);
    }

    @Override
    public String toString() {
        return "Programmer{" +
                "name='" + name + '\'' +
                ", age=" + age +
                ", salary=" + salary +
                ", des='" + des + '\'' +
                '}';
    }
}