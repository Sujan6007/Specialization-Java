package com.Collections2;

import java.util.Scanner;

public class Clerk extends Emp{
    public Clerk(String name,int age,int sal,String des) {
        this.name = name;
        this.age = age;
        this.salary = sal;
        this.des = des;
    }
    public Clerk(int raise){
        this.raise = raise;
    }
    @Override
    public void raise(int r){
        this.salary = this.salary+this.raise;
        System.out.println("The total is"+ this.salary);
    }
    public void display(){
        System.out.println(this.name+" "+this.age+" "+this.salary+" "+this.des);
    }
//



    @Override
    public String toString() {
        return "Clerk{" +
                "name='" + name + '\'' +
                ", age=" + age +
                ", salary=" + salary +
                ", des='" + des + '\'' +
                '}';
    }
}
