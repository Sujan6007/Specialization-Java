package com.Collections2;

public class Emp {
    String name;
    int age;
    int salary;
    String des;
    int raise;
    public void raise(int raise){
        this.salary = this.salary+this.raise;
        System.out.println("The total is"+ this.salary);
    }

}
