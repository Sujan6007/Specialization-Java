package com.demo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class User {
    private String name;
    private int age;


    public String getName() {
        return name;
    }


    public void setName(String name) {
        this.name = name;
    }


    public int getAge() {
        return age;
    }


    public void setAge(int age) {
        this.age = age;
    }


    @Override
    public String toString() {
        return "User{" +
                "name='" + name + '\'' +
                ", age=" + age +
                '}';
    }


    public User(String name, int age) {
        this.name = name;
        this.age = age;
    }

    // Constructor, getters, setters and toString()
    public static void main(String[] args) {


       List<User> userList = new ArrayList<>(Arrays.asList(
                new User("Nortje", 10),
                new User("Archer", 30),
                new User("Steyn", 20),
                new User("Anderson", 40)));
        List<User> sortedList = userList.stream()
                .sorted(Comparator.comparingInt(User::getAge).reversed())
                .collect(Collectors.toList());


        sortedList.forEach(System.out::println);
    }
}
