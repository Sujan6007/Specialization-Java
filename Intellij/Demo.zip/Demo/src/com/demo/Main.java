package com.demo;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        List<Student> std = new ArrayList<Student>();
        std.add(new Student(3,"sujan",21));
        std.add(new Student(2,"ram",22));
        std.add(new Student(1,"ajay",20));


        std.stream()
                .sorted((Student p1, Student p2) ->p1.name.compareTo(p2.name))
                .forEach(System.out::println);


    }

}

