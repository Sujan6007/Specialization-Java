package com.Assignments;

public class Five {
    void printRepeating(int arr[], int size)
    {
        int i, j,sum=0;
        System.out.println("Repeated Elements are :");
        for (i = 0; i < size; i++)
        {
            for (j = i + 1; j < size; j++)
            {
                if (arr[i] == arr[j])
                    System.out.print(arr[i] + " ");
            }
        }
    }

    public static void main(String[] args)
    {
        Five obj = new Five();
        int arr[] = {1,1,1,1,1};
        int arr_size = arr.length;
        obj.printRepeating(arr, arr_size);
    }
}
