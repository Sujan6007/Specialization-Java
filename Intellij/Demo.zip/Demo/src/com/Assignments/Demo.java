package com.Assignments;
import java.util.*;

public class Demo {
    public static void main(String[] args)
    {
        Scanner sc= new Scanner(System.in);
        System.out.println("enter the number to be rounded-off");
        double number = sc.nextDouble();
// rounding number to 2 decimal places
        System.out.format("%.2f", number);
    }
}
