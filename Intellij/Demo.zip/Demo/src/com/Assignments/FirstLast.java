package com.Assignments;

import java.util.Scanner;

public class FirstLast {
    public static void main(String[] args) {
        System.out.println("Enter the number");
        Scanner sc = new Scanner(System.in);
        int num= sc.nextInt();
        int fNum=0;
        int lNum =0;
        lNum = num%10;
        while (num!=0){
            fNum= num % 10;
            num/=10;
        }
        if(fNum==lNum){
            System.out.println("They are equal");
        }
        else
        {
            System.out.println("they are different");
        }

}}








