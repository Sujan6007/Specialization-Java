package com.collections;

import java.util.ArrayList;
import java.util.List;

public class EmpDemo {
    public static void main(String[] args) {
        Emp obj1 = new Emp("Sujan",1,"IT",25000);
        Emp obj2 = new Emp("Suraj",2,"IT",25000);
        Emp obj3 = new Emp("Suhas",3,"IT",25000);
        Emp obj4 = new Emp("Sudarshan",4,"HR",25000);

        List<Emp> list = new ArrayList<>();
        list.add(obj1);
        list.add(obj2);
        list.add(obj3);
        list.add(obj4);
        Emp emp;
        for (int i=0;i<list.size();i++){
            emp=list.get(i);
            if(emp.getDept().equalsIgnoreCase("HR")){
                emp.setSalary(emp.getSalary()+5000);
            }
        }
        System.out.println(list);
    }
}

