class abc{
    constructor(){
        setTimeout( () =>{
                console.log('hello this is set timeout function');
        },5000)
    }
}
var a = new abc();