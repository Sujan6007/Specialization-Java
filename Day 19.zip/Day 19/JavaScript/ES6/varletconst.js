// var name="sujan";
// function abc(){
//     name="suraj";
//     console.log(name);

// }
// abc()
function abc(){
    var fruits=["apple","grapes","orange","mango"]
    for (let index = 0; index < fruits.length; index++) {
        var element = fruits[index];
        console.log(element);
    }   
    console.log(element);
    console.log(fruits);
    // console.log(index);
    }
abc();

console.log('template string')
var message =`This is 
            a message
            from google`
console.log(message);