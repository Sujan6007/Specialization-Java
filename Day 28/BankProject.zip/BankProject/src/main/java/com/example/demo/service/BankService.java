package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Bank;
import com.example.demo.repo.BankRepo;


@Service
public class BankService {
	@Autowired
    BankRepo repo;

    public void store(Bank bnk) {
        repo.save(bnk);
    }
 
    public List<Bank> getUsers() {

        List<Bank> list=repo.findAll();    

        return list;
    }
 
    public Bank getUser(int accntno) {

        Bank bnk=repo.findById(accntno).orElse(new Bank());

        return bnk;
    }
 
    public void deleteUser(int accntno) {
        repo.deleteById(accntno);
    }



}
