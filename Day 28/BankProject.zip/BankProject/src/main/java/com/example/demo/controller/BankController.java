package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Bank;
import com.example.demo.service.BankService;



@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class BankController {
	@Autowired
    BankService service;

    @PostMapping( value = "/saveUser" ,consumes = MediaType.APPLICATION_JSON_VALUE ,produces = MediaType.APPLICATION_JSON_VALUE )
    public ResponseEntity<Bank> print(@RequestBody Bank bnk)
    {   
        service.store(bnk);
        return new ResponseEntity<Bank>(bnk,HttpStatus.CREATED);
    }

    @GetMapping( value = "/Users" ,produces = MediaType.APPLICATION_JSON_VALUE )
    public ResponseEntity <List<Bank>> getUsers()
    {   
        List<Bank> list=service.getUsers();
        return new ResponseEntity<List<Bank>>(list,HttpStatus.CREATED);
    }

    @GetMapping( value = "/User/{accntno}" ,produces = MediaType.APPLICATION_JSON_VALUE )
    public ResponseEntity<Bank> getUser(@PathVariable("accntno") int accntno)
    {   
        Bank bnk =service.getUser(accntno);
        return new ResponseEntity<Bank>(bnk,HttpStatus.CREATED);
    }

    @PutMapping( value = "/User" ,produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Bank> updateUser(@RequestBody Bank bnk)
    {   
        service.store(bnk);
        return new ResponseEntity<Bank>(bnk,HttpStatus.CREATED);
    }

    @DeleteMapping( value = "/delete/{accntno}" ,consumes = MediaType.APPLICATION_JSON_VALUE )
    public ResponseEntity<String> deleteUser(@PathVariable("accntno") int accntno)
    {   
        service.deleteUser(accntno);
        return new ResponseEntity<String>("recored deleted",HttpStatus.CREATED);
    }

}
