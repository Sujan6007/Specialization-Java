export class Bank {
        accntno:number=0;
        fullname:string=""; 
        email:string=""; 
        password:string=""; 
        confirmpswd:string=""; 
        mobileno:string="";
}