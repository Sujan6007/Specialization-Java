import { Component } from '@angular/core';
import { SignupService } from './signup.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'bank';
  users:any=[];
  constructor(private usr:SignupService){}

  ngOnInit(): void {
      this.usr.getAllUser().subscribe((data)=>{
        this.users=data;
        console.log(data);
      }
      )
  }
}
