import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Bank } from 'src/bank';

@Injectable({
  providedIn: 'root'
})
export class SignupService {
  private _URL:string="http://localhost:8000";
  constructor(private http:HttpClient) { }

saveEmp(usr:Bank):Observable<Bank>{

  return this.http.post<Bank>(`${this._URL}/saveUser`,usr);
  
}
getAllUser():Observable<Bank[]>{
  return this.http.get<Bank[]>(`${this._URL}/Users`);
}
}
