import { Component, OnInit } from '@angular/core';
import { Bank } from 'src/bank';
import { SignupService } from '../signup.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
usr :Bank = new Bank();
  constructor(public user:SignupService) { }

  ngOnInit(): void {
  }
  save(obj:any){
    this.usr.accntno=obj.accntno;
    this.usr.fullname=obj.fullname;
    this.usr.email=obj.email;
    this.usr.password=obj.password;
    this.usr.confirmpswd=obj.confirmpswd;
    this.usr.mobileno=obj.mobileno;
    if(this.usr!=null){
    this.user.saveEmp(this.usr).subscribe((res: any)=>{
      console.log(res);
    }
    );
    }
  }

}
