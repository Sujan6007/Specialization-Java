import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  email:string=" ";
  password:string=" ";
  prop:string=" ";
  msg:string="";
  valid:boolean=true;


  constructor() { }

  ngOnInit(): void {
  }
  login(value:any){
    if(value.email=="sujan@gmail.com" && value.password=="123456"){
      this.msg=`Successfully logged in`; 
      this.prop=`#006400`;
    }else{
      this.msg=`login not succesful`; this.prop=`red`;
    }
    console.log(value.emailid);
   console.log(value.password); 

}
}