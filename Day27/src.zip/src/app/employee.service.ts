import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  constructor() { }

saveEmp(emp:any){
  console.log(emp);
  
}}